# Technikpaten
## Persönliche Technikhilfe in Rendsburg und Umgebung

Ich bin **Finn Ole Bierlich**. Ich unterstütze Sie bei Fragen zu Smartphone, Tablet, Computer, Drucker und WLAN und erkläre die Schritte in Ruhe. Termine werden persönlich vereinbart. Auch Angehörige können einen Termin organisieren.

| Angebot | Preis | Umfang |
| --- | --- | --- |
| **Fernhilfe** | **29 €** | Bis **30 Minuten** nach Terminvereinbarung für **ein konkretes, begrenztes Problem**. Nur wenn die Unterstützung technisch möglich ist. |
| **Technikhilfe zu Hause** | **69 €** | Bis **60 Minuten** Diagnose und Unterstützung beim vorher vereinbarten Technikproblem. Eine Lösung kann nicht garantiert werden. |
| **Neues Gerät startklar** | **99 €** | Bis **90 Minuten** für **ein neues Smartphone, Tablet oder einen Computer**: Grundverbindung, Konten, ausgewählte technisch mögliche Datenübernahme und kurze Einweisung. |

## Anfahrt

- **Rendsburg und Büdelsdorf:** bei beiden Vor-Ort-Paketen inklusive.
- **Fockbek, Westerrönfeld und Osterrönfeld:** zusätzlich **10 € je Termin**, insgesamt für Hin- und Rückfahrt.
- **Weitere Orte:** Gesamtpreis einschließlich Anfahrt vor der Terminbestätigung.

## Kosten und Leistungsumfang

Alle Preise sind **Endpreise**. Die Leistungen sind gemäß **§ 19 UStG umsatzsteuerfrei**.

Die genannte Dauer umfasst alle Bestandteile des jeweiligen Pakets. Der Paketpreis gilt auch, wenn der Termin kürzer dauert. Für **alle Pakete** kostet zusätzliche Zeit **15 € je weitere angefangene 15 Minuten**, ausschließlich nach Ihrer vorherigen Freigabe. **Es gibt keine automatische Verlängerung.**

Hardware, Ersatzteile, Lizenzen, größere Datenrettung und Elektronikreparaturen sind nicht enthalten. Größere Datenmigrationen und die Einrichtung mehrerer Geräte werden separat kalkuliert. Umfang und Kosten werden vor dem Termin besprochen. Zeitpakete enthalten keine Garantie für eine vollständige Problemlösung oder Datenübernahme.

**Kein Abonnement. Kein Notdienst.** Termine nach Vereinbarung.

## Einfache Preisbeispiele

- 25 Minuten Fernhilfe: **29 €**.
- Fernhilfe mit zuvor freigegebener Verlängerung auf insgesamt 40 Minuten: **44 €**.
- Bis 60 Minuten Technikhilfe zu Hause in Rendsburg: **69 €**.
- Ein neues Gerät bis 90 Minuten in Fockbek, einschließlich Anfahrt: **109 €**.

## Kontakt und Terminvereinbarung

**Technikpaten · Finn Ole Bierlich**  
Wallstraße 34 · 24768 Rendsburg

**Telefon: [0171 28 07 197](tel:+491712807197)**  
**WhatsApp: [0171 28 07 197](https://wa.me/491712807197)**  
**E-Mail: [uhighcauseidope@gmail.com](mailto:uhighcauseidope@gmail.com)**  
**Website: [technikpaten.bierlich.cloud](https://technikpaten.bierlich.cloud)**

Stand: 6. September 2026.
