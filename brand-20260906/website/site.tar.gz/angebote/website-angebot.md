# Bierlich – Websites für kleine Unternehmen

**Persönlich betreut. Klarer Umfang. Vereinbarter Festpreis.**

## Websitepakete

| | **Kompakt** | **Unternehmenswebsite** | **Website Plus** |
|---|---|---|---|
| **Einmaliger Endpreis** | **450 €** | **790 €** | **1.190 €** |
| Umfang | Ein Onepager, bis fünf Abschnitte | Bis vier Inhaltsseiten | Bis sechs Inhaltsseiten |
| Textfeinschliff gelieferter Texte | Bis insgesamt 400 Wörter | Bis insgesamt 800 Wörter | Bis insgesamt 1.200 Wörter |
| Gebündelte Korrekturrunden | Eine | Zwei | Zwei |
| Kontakt | Telefon, E-Mail, WhatsApp | Zusätzlich Standardformular, wenn die Mailvoraussetzungen erfüllt sind | Zusätzlich Standardformular, wenn die Mailvoraussetzungen erfüllt sind |
| Weitere Leistungen | Kurzes Briefing | Mehrseitige Darstellung Ihres Betriebs | Strukturierte Leistungen und FAQ innerhalb des Seitenlimits, vorhandenen Kalender einfach anschließen, 30 Minuten Einweisung |

**In allen Paketen:** eine Sprache, ein Designentwurf, Darstellung auf Smartphone und Desktop, kurze Abstimmung sowie technische SEO-Grundlagen mit passenden Seitentiteln, Beschreibungen und einer sinnvollen Überschriftenstruktur. Die höheren Pakete haben eigene Gesamtgrenzen; Seiten-, Wort- und Korrekturkontingente werden nicht addiert.

**Kontaktformular:** höchstens fünf Felder, ein Empfänger. Voraussetzung ist ein geeigneter, eingerichteter Maildienst. Verfügbarkeit, nötige Einrichtung und Gebühren werden vor Beauftragung geklärt; externe Gebühren sind separat. Eine automatische Zustellung ist erst nach Einrichtung und Prüfung verfügbar.

**Vorhandener Kalender bei Website Plus:** ein geeigneter bestehender Kalender wird per Link oder einfacher Einbettung angeschlossen. Die Einrichtung eines neuen Buchungstools ist separat buchbar.

Impressum und Datenschutz werden zusätzlich mit Ihren freigegebenen Texten eingebaut. Sie liefern Logo, Bilder und fachliche Fakten sowie die zu bearbeitenden Texte. Bildgenerierung, Logoentwicklung, vollständig neue Texte, Shop, Mitgliederbereiche, Mehrsprachigkeit und komplexe Integrationen gehören nicht zum Festpreis. Korrekturrunden betreffen gebündelte Änderungen innerhalb des vereinbarten Entwurfs.

## Hosting auf Wunsch

| Wahl | Monatlicher Endpreis | Umfang |
|---|---:|---|
| Eigenes Hosting | Kein Bierlich-Hostingabo | Übergabe und technische Voraussetzungen werden vereinbart. |
| Hosting | **19 €** | HTTPS, Erreichbarkeitskontrolle und versionierte Sicherung für die kleine Unternehmenswebsite. Keine Inhaltsänderungen enthalten. |
| Hosting & Pflege | **49 € insgesamt** | Alle Hosting-Leistungen, bis 20 Minuten Inhaltsänderungen monatlich, nicht übertragbar, sowie erforderliche technische Pflege im vereinbarten Umfang. |

Beide Hostingangebote sind optional und monatlich zum Monatsende kündbar. Es gibt keine 24/7-Betreuung. Domain, E-Mail und Lizenzen werden gesondert ausgewiesen. Konkrete Betriebsabläufe, Erreichbarkeitskontrolle und versionierte Sicherung werden bei gewähltem Hosting vor Kundenbetrieb vereinbart, eingerichtet und geprüft; die Wiederherstellung wird getestet. Die Website kann ohne verpflichtendes Bierlich-Hosting übernommen werden; notwendige Anschlüsse an andere Anbieter werden vorher erklärt.

## Sinnvolle Erweiterungen

| Leistung | Endpreis | Begrenzung |
|---|---:|---|
| Weitere Inhaltsseite | **99 €** | Vorhandenes Layout, gelieferte Inhalte. |
| Zusätzliche Arbeit | **69 €/Stunde** | Nach Freigabe, Abrechnung in 15-Minuten-Einheiten zu **17,25 €**. |
| Buchungstool einrichten | **Ab 149 € einmalig** | Ein Kalender, ein Standort, bis drei Terminarten; Lizenz extra. |
| Lokaler Sichtbarkeits-Start | **199 € einmalig** | Ein Standort: bestehendes Google-Profil prüfen oder berechtigte Einrichtung begleiten, Unternehmensdaten, Seitentitel und Maßnahmenliste. |
| Unternehmensdaten & AI-Listings | **149 € einmalig** | Optional: Unternehmensdaten und strukturierte Informationen prüfen beziehungsweise aufbereiten; bis drei relevante Verzeichnisse. Keine Garantie für KI-Erwähnungen. |
| Standard-Automation | **Ab 490 €** | Gesondertes Angebot für einen bewährten Standardablauf über [automation.bierlich.cloud](https://automation.bierlich.cloud). |
| Google Ads | **290 € Einrichtung + 149 €/Monat** | Optional: bis 90 Minuten Betreuung, eine Suchkampagne, eine Region, bis zwei Anzeigengruppen. Werbebudget extra. |

Fremdlizenzen und laufende Anbietergebühren werden vor Beauftragung benannt. Suchplatzierungen, KI-Erwähnungen, Anfragen und Umsätze werden nicht garantiert. Umfang und Termine vereinbaren wir für Ihr konkretes Vorhaben.

**Alle eigenen Preise sind Endpreise. Umsatzsteuerfrei gemäß § 19 UStG.**

## Kontakt

**Finn Ole Bierlich** · Wallstraße 34 · 24768 Rendsburg  
Telefon: **+49 171 2807197**  
E-Mail: **uhighcauseidope@gmail.com**  
[E-Mail vorbereiten](mailto:uhighcauseidope@gmail.com) · [WhatsApp öffnen](https://wa.me/491712807197)

Die Kontaktwege öffnen Ihr E-Mail-Programm beziehungsweise WhatsApp. Sie senden Ihre Nachricht selbst ab.

*Stand: 6. September 2026.*
